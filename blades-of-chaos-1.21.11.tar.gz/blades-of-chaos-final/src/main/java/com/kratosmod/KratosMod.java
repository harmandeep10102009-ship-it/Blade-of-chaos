package com.kratosmod;

import com.kratosmod.combat.ComboTracker;
import com.kratosmod.fx.ChainVisual;
import com.kratosmod.item.ModItems;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public class KratosMod implements ModInitializer {
    public static final String MOD_ID = "kratosmod";

    @Override
    public void onInitialize() {
        ModItems.initialize();
        ChainVisual.register();
        AttackEntityCallback.EVENT.register((player, level, hand, entity, hitResult) -> {
            ItemStack stack = player.getItemInHand(hand);
            if (!level.isClientSide && level instanceof ServerLevel serverLevel
                    && stack.getItem() == ModItems.BLADES_OF_CHAOS && entity instanceof LivingEntity target) {
                int combo = ComboTracker.registerHit(player);
                applyComboEffects(serverLevel, player, target, combo);
            }
            return InteractionResult.PASS;
        });
    }

    private void applyComboEffects(ServerLevel level, net.minecraft.world.entity.player.Player player, LivingEntity target, int combo) {
        Vec3 pushDir = target.position().subtract(player.position()).normalize();
        double knockback = 0.15 * combo;
        target.setDeltaMovement(target.getDeltaMovement().add(pushDir.x * knockback, 0.08 * combo, pushDir.z * knockback));
        target.hurtMarked = true;
        int particleCount = 2 + combo * 2;
        level.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY(0.5), target.getZ(), particleCount, 0.2, 0.2, 0.2, 0.02);
        float pitch = 0.8f + (combo * 0.08f);
        level.playSound(null, target.blockPosition(), SoundEvents.CHAIN_HIT, SoundSource.PLAYERS, 1.0f, pitch);
        if (combo >= ComboTracker.MAX_COMBO) {
            level.sendParticles(ParticleTypes.SWEEP_ATTACK, target.getX(), target.getY(0.5), target.getZ(), 1, 0.0, 0.0, 0.0, 0.0);
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 2));
            level.playSound(null, target.blockPosition(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS, 1.0f, 0.7f);
        }
    }
}
