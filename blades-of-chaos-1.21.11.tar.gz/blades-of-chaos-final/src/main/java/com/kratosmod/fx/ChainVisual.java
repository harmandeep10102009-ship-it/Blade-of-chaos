package com.kratosmod.fx;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

public final class ChainVisual {
    private static final int STEPS = 6;
    private static final List<Task> QUEUE = new ArrayList<>();

    private ChainVisual() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(ChainVisual::tick);
    }

    public static void playChainPull(ServerLevel level, Vec3 from, Vec3 to, Runnable onArrive) {
        QUEUE.add(new Task(level, from, to, onArrive));
    }

    private static void tick(net.minecraft.server.MinecraftServer server) {
        if (QUEUE.isEmpty()) return;

        List<Task> finished = new ArrayList<>();
        for (Task task : QUEUE) {
            task.step++;
            double frac = (double) task.step / STEPS;

            Vec3 pos = task.from.add(task.to.subtract(task.from).scale(Math.min(frac, 1.0)));
            task.level.sendParticles(ParticleTypes.CRIT, pos.x, pos.y, pos.z, 2, 0.04, 0.04, 0.04, 0.0);
            task.level.sendParticles(ParticleTypes.SMOKE, pos.x, pos.y, pos.z, 1, 0.02, 0.02, 0.02, 0.0);

            if (task.step >= STEPS) {
                task.level.sendParticles(ParticleTypes.SWEEP_ATTACK, task.to.x, task.to.y, task.to.z, 1, 0.0, 0.0, 0.0, 0.0);
                task.onArrive.run();
                finished.add(task);
            }
        }
        QUEUE.removeAll(finished);
    }

    private static final class Task {
        final ServerLevel level;
        final Vec3 from;
        final Vec3 to;
        final Runnable onArrive;
        int step = 0;

        Task(ServerLevel level, Vec3 from, Vec3 to, Runnable onArrive) {
            this.level = level;
            this.from = from;
            this.to = to;
            this.onArrive = onArrive;
        }
    }
}
