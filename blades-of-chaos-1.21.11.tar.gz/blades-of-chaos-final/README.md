# Blades of Chaos — Minecraft 1.21.11 Fabric Mod

A dual-blade weapon inspired by God of War. Chain-pull enemies closer and build combos through successive melee hits.

## Features

- **Right-Click Chain Pull** — Target enemies and yank them toward your position
- **Combo System** — Successive hits escalate knockback and particle effects (5-hit finisher)
- **Netherite-Tier Durability** — Fast, hard-hitting sword

## Building

```bash
./gradlew runClient
```

## Customize

- **Attack Damage:** Edit `new Item.Properties().sword(ToolMaterial.NETHERITE, 7.0F, -1.5F)` in `ModItems.java`
- **Combo Window:** Change `COMBO_WINDOW_TICKS` in `ComboTracker.java` (40 = 2 seconds)
- **Texture:** Replace `blades_of_chaos.png`

## License

MIT
