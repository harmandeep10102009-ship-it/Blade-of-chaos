# Blades of Chaos — Minecraft 1.21.11 Fabric Mod

A dual-blade weapon inspired by God of War. Chain-pull enemies closer and build combos through successive melee hits.

## Features

- **Right-Click Chain Pull** — Target the closest enemy in front of you and yank them toward your position. Animated chain particles travel from hand to target. Pulls deal knockback + damage + slowness effect.
- **Combo System** — Consecutive melee hits within 2 seconds escalate knockback, particle density, and pitch. Hitting 5 times in quick succession triggers a finisher burst that briefly slows enemies.
- **Netherite-Tier Durability** — Swings fast like a sword, hits hard.

## Building

**Requirements:**
- JDK 21+
- Gradle (included via `./gradlew` wrapper)

**Steps:**

```bash
# On Windows
./gradlew.bat build

# On macOS / Linux
./gradlew build
```

The compiled JAR will be in `build/libs/`.

**To run in-game (dev mode):**

```bash
./gradlew runClient
```

Then use `/give @s kratosmod:blades_of_chaos` to grab the weapon.

## File Structure

```
src/main/java/com/kratosmod/
├── item/
│   ├── ModItems.java          (Registration)
│   └── BladesOfChaosItem.java (Right-click ability)
├── fx/
│   └── ChainVisual.java       (Particle animations)
├── combat/
│   └── ComboTracker.java      (Combo counter)
└── KratosMod.java             (Entrypoint)

src/main/resources/
├── fabric.mod.json
└── assets/kratosmod/
    ├── lang/en_us.json        (Translations)
    ├── models/item/           (Item model)
    ├── items/                 (Client item definition)
    └── textures/item/         (Texture PNG)
```

## Customization

- **Attack Damage:** Modify the float in `ModItems.register()` (currently `7.0F`)
- **Attack Speed:** Modify the float in `ModItems.register()` (currently `-1.5F`)
- **Chain Range:** Edit `RANGE` in `BladesOfChaosItem.java`
- **Combo Window:** Change `COMBO_WINDOW_TICKS` in `ComboTracker.java` (currently 40 ticks = 2 seconds)
- **Texture:** Replace `blades_of_chaos.png` in `src/main/resources/assets/kratosmod/textures/item/`

## License

MIT
