package com.kratosmod.combat;

import net.minecraft.world.entity.player.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Tracks consecutive Blades of Chaos hits per player.
 * A combo resets if too much time passes between hits.
 * Capped at 5 for the finisher effect.
 */
public final class ComboTracker {

    private static final int COMBO_WINDOW_TICKS = 40; // 2 seconds
    public static final int MAX_COMBO = 5;

    private static final Map<UUID, ComboState> COMBOS = new HashMap<>();

    private ComboTracker() {
    }

    public static int registerHit(Player player) {
        long now = player.level().getGameTime();
        ComboState state = COMBOS.computeIfAbsent(player.getUUID(), id -> new ComboState());

        if (now - state.lastHitTick > COMBO_WINDOW_TICKS) {
            state.hits = 0;
        }

        state.hits = Math.min(state.hits + 1, MAX_COMBO);
        state.lastHitTick = now;
        return state.hits;
    }

    private static final class ComboState {
        int hits = 0;
        long lastHitTick = Long.MIN_VALUE;
    }
}
