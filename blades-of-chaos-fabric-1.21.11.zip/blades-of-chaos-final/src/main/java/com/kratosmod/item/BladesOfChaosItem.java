package com.kratosmod.item;

import com.kratosmod.fx.ChainVisual;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Right-click: fires an invisible "chain" forward. The closest living entity
 * within a forward-facing cone gets yanked toward the player and takes damage.
 *
 * Left-click melee damage/speed come from the vanilla "sword" item component.
 * Combo scaling on melee hits is handled separately via AttackEntityCallback.
 */
public class BladesOfChaosItem extends Item {

    private static final double RANGE = 8.0;
    private static final double CONE_THRESHOLD = 0.6;
    private static final int COOLDOWN_TICKS = 20;

    public BladesOfChaosItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.pass(stack);
        }

        if (!level.isClientSide && level instanceof ServerLevel serverLevel) {
            LivingEntity target = findChainTarget(level, player);

            if (target != null) {
                pullAndStrike(serverLevel, player, target);
            } else {
                serverLevel.playSound(null, player.blockPosition(), SoundEvents.ITEM_FLINTANDSTEEL_USE,
                        SoundSource.PLAYERS, 0.5f, 1.6f);
            }
        }

        player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
        player.swing(hand);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    private LivingEntity findChainTarget(Level level, Player player) {
        Vec3 eyePos = player.getEyePosition(1.0f);
        Vec3 lookVec = player.getViewVector(1.0f);
        AABB searchBox = player.getBoundingBox().inflate(RANGE);

        List<LivingEntity> candidates = level.getEntitiesOfClass(
                LivingEntity.class,
                searchBox,
                e -> e != player && e.isAlive() && player.hasLineOfSight(e)
        );

        LivingEntity best = null;
        double bestDot = CONE_THRESHOLD;

        for (LivingEntity e : candidates) {
            Vec3 toEntity = e.position().subtract(eyePos).normalize();
            double dot = lookVec.dot(toEntity);
            if (dot > bestDot) {
                bestDot = dot;
                best = e;
            }
        }

        return best;
    }

    private void pullAndStrike(ServerLevel level, Player player, LivingEntity target) {
        Vec3 handPos = player.getEyePosition(1.0f);
        Vec3 targetPos = target.position().add(0, target.getBbHeight() * 0.5, 0);

        ChainVisual.playChainPull(level, handPos, targetPos, () -> {
            Vec3 pullDir = player.position().subtract(target.position()).normalize();
            target.setDeltaMovement(pullDir.x * 1.4, 0.35, pullDir.z * 1.4);
            target.hurtMarked = true;

            target.hurt(level.damageSources().playerAttack(player), 4.0f);
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 1));

            level.playSound(null, player.blockPosition(), SoundEvents.CHAIN_BREAK,
                    SoundSource.PLAYERS, 1.0f, 0.7f);
        });
    }
}
